﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using BlockLimiter.Limits;
using BlockLimiter.Settings;
using BlockLimiter.Utility;
using NLog;
using Sandbox.Game.Entities;
using Sandbox.Game.Entities.Cube;
using Sandbox.Game.World;
using Torch.Mod;
using Torch.Mod.Messages;
using VRage.Game;
using VRage.Game.Entity;
using Timer = System.Timers.Timer;

namespace BlockLimiter.Punishment
{
    public class Annoy : LimitsBase
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();
        
        public override int GetUpdateResolution()
        {
            return BlockLimiterConfig.Instance.AnnoyInterval*1000;
        }

        public override void Handle()
        {
            if (!BlockLimiterConfig.Instance.Annoy)return;
            var vanillaLimits = new List<LimitItem>();
            var limiterLimits = BlockLimiterConfig.Instance.LimitItems.Where(x => x.ViolatingEntities?.Any()==true).ToList();
            if (BlockLimiterConfig.Instance.UseVanillaLimits)
            {
                vanillaLimits = BlockLimiter.Instance.VanillaLimits.Where(x => x.ViolatingEntities.Any())
                    .ToList();
            }

            var newList = new List<LimitItem>(limiterLimits.Count + vanillaLimits.Count + 1);
            newList.AddRange(limiterLimits);
            newList.AddRange(vanillaLimits);

            if (!newList.Any())return;

            var onlinePlayers = MySession.Static.Players.GetOnlinePlayers().ToList();
            var annoyList = new List<ulong>();
            var violatingEntities = newList.SelectMany(x => x.ViolatingEntities.Keys).ToList();
            if (!onlinePlayers.Any() || !violatingEntities.Any())return;


            foreach (var player in onlinePlayers)
            {
                var playerId = player.Id.SteamId;
                
                if (annoyList.Contains(playerId))continue;

                var playerFaction = MySession.Static.Factions.GetPlayerFaction(player.Identity.IdentityId);
                foreach (var identity in violatingEntities)
                {
                    

                    if (identity == player.Identity.IdentityId)
                    {
                        annoyList.Add(playerId);
                        break;
                    }

                    if (EntityCache.TryGetEntityById(identity, out var grid) && ((MyCubeGrid)grid).BigOwners.Contains(player.Identity.IdentityId))
                    {
                        annoyList.Add(playerId);
                        break;
                    }

                    if (playerFaction == null || identity != MySession.Static.Factions.GetPlayerFaction(player.Identity.IdentityId).FactionId) continue;
                    if (identity != MySession.Static.Factions.GetPlayerFaction(player.Identity.IdentityId).FactionId)
                        continue;
                    annoyList.Add(playerId);
                    break;


                }
            }
            if (!annoyList.Any())return;

            foreach (var id in annoyList)
            {
                try
                {
                    ModCommunication.SendMessageTo(new NotificationMessage($"{BlockLimiterConfig.Instance.AnnoyMessage}",BlockLimiterConfig.Instance.AnnoyDuration,MyFontEnum.White),id);
                }
                catch (Exception exception)
                {
                    Log.Debug(exception);
                }
            }

            Log.Debug($"Blocklimiter annoyed {annoyList.Count} players");

        }





    }
}