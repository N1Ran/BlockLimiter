﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BlockLimiter.Limits;
using BlockLimiter.Settings;
using BlockLimiter.Utility;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine.Multiplayer;
using Sandbox.Game.Entities;
using Sandbox.Game.Entities.Character;
using Sandbox.Game.World;
using Sandbox.ModAPI;
using Torch.Commands;
using Torch.Mod;
using Torch.Mod.Messages;
using VRage.Game;
using VRage.ObjectBuilders;

namespace BlockLimiter.Commands
{
    public partial class Player
    {
        [Command("violations", "gets the list of violations per limit")]
        public void GetViolations()
        {
            var newList = new List<LimitItem>();
            var limiterLimits = BlockLimiterConfig.Instance.LimitItems.Where(l=>l.ViolatingEntities.Any()).ToList();
            if (BlockLimiterConfig.Instance.UseVanillaLimits && BlockLimiter.Instance.VanillaLimits?.Any()==false)
            {
                var vanillaLimits = BlockLimiter.Instance.VanillaLimits.Where(x => x.ViolatingEntities.Any())
                    .ToList();
                newList.AddRange(vanillaLimits);
            }
            
            newList.AddRange(limiterLimits);

            if (!newList.Any())
            {
                Context.Respond("No violations found");
                return;
            }
            var sb = new StringBuilder();
            foreach (var item in newList)
            {
                var limitName = string.IsNullOrEmpty(item.Name) ? item.BlockPairName.FirstOrDefault() : item.Name;
                var disabledEntities = item.ViolatingEntities.Select(y=>y.Key).ToList();
                var factions = disabledEntities.Select(de => MySession.Static.Factions.TryGetFactionById(de)).Where(x=>x!=null).ToList();
                var players = disabledEntities.Select(de => MySession.Static.Players.TryGetIdentity(de)).Where(x=>x!=null).ToList();
                var grids = disabledEntities.Select(de => MyEntities.GetEntityById(de)).OfType<MyCubeGrid>().ToList();
                sb.AppendLine();
                sb.AppendLine($"{limitName}");
                
                if (factions.Any())
                {
                    sb.AppendLine("Violating Factions: ");
                    factions.ForEach(f=>sb.AppendLine($"[{f.Name} -- {f.Tag}]"));
                }
                
                if (players.Any())
                {
                    sb.AppendLine("Violating Players: ");
                    players.ForEach(f=>sb.Append($"[{f.DisplayName} -- {f.IdentityId}]"));
                    sb.AppendLine();
                }

                if (grids.Any())
                {
                    sb.AppendLine("Violating Grids: ");
                    grids.ForEach(f=>sb.AppendLine($"[{f.DisplayName} -- {f.EntityId}]"));
                }


            }


            if (Context.Player == null || Context.Player.IdentityId == 0)
            {
                Context.Respond(sb.ToString());
                return;
            }

            ModCommunication.SendMessageTo(new DialogMessage(BlockLimiterConfig.Instance.ServerName,"List of Violatons",sb.ToString()),Context.Player.SteamUserId);

        }

       /* [Command("add", "gets the list of disabled players per limit")]
        public void AddLimit()
        {
            if (!Context.Args.Any())
            {
                Context.Respond("Limit info needed");
                return;
            }

            var limit = new LimitItem();

            foreach (var arg in Context.Args)
            {
                if (arg.StartsWith("--name="))
                {
                    limit.Name = arg.Substring("newname=".Length);
                    continue;
                }

                if (arg.StartsWith("--addblocks="))
                {
                    var ns = arg.Substring("--addblocks=".Length);
                    var blockList = ns.Split('"', ',');

                    blockList.ForEach(bl=>limit.BlockPairName.Add(bl));
                    Context.Respond("Blocks added to limit");
                    continue;
                }

                if (arg.StartsWith("--limit="))
                {
                    limit.Limit = int.Parse(arg.Substring("--limit=".Length));
                    continue;
                }

                if (arg.StartsWith("--projector="))
                {
                    limit.RestrictProjection = bool.Parse(arg.Substring("--projector=".Length));
                    continue;
                }

                if (arg.StartsWith("--player="))
                {
                    limit.LimitPlayers = bool.Parse(arg.Substring("--player=".Length));
                    continue;
                }

                if (arg.StartsWith("--grid="))
                {
                    limit.LimitGrids = bool.Parse(arg.Substring("--grid=".Length));
                    continue;
                }

                if (arg.StartsWith("--faction="))
                {
                    limit.LimitFaction = bool.Parse(arg.Substring("--faction=".Length));
                    continue;
                }

            }

            BlockLimiterConfig.Instance.LimitItems.Add(limit);
        }

        [Command("remove", "removes a limit")]
        public void RemoveLimit(string name)
        {
            var itemsToRemove = BlockLimiterConfig.Instance.LimitItems.Where(x =>
                x.Name.Equals(name,StringComparison.OrdinalIgnoreCase));
            var limitItems = itemsToRemove as LimitItem[] ?? itemsToRemove.ToArray();
            if (!limitItems.Any())
            {
                Context.Respond("No limit item by that name found");
                return;
            }

            var removedCount = limitItems.Count();
            try
            {
                limitItems.ForEach(l=>BlockLimiterConfig.Instance.LimitItems.Remove(l));
            }
            catch (Exception e)
            {
               //ignore
            }
            Context.Respond($"Removed {removedCount} items from the limit list.");
        }
        */
        [Command("pairnames", "gets the list of all pairnames possible. BlockType is case sensitive")]
        public void ListPairNames(string blockType=null)
        {
            var sb = new StringBuilder();

            var allDef = MyDefinitionManager.Static.GetAllDefinitions();

            var def = new List<MyDefinitionBase>();

            if (!string.IsNullOrEmpty(blockType))
            {
                foreach (var defBase in allDef)
                {
                    if (!defBase.Id.TypeId.ToString().Substring(16).Equals(blockType,StringComparison.OrdinalIgnoreCase))
                        continue;
                    def.Add(defBase);
                }

                if (!def.Any())
                {
                    Context.Respond($"Can't find any definition for {blockType}");
                    return;
                }

            }

            else
            {
                def.AddRange(allDef);
            }

            if (!def.Any())
            {
                Context.Respond("Na Bruh!");
                return;
            }

            sb.AppendLine($"Total of {def.Count} definitions found on server");
            foreach (var myDefinitionId in def)
            {
                var modId = "0";
                var modName = "Vanilla";
                if (myDefinitionId.Context?.IsBaseGame == false)
                {
                    modId = myDefinitionId.Context?.ModId;
                    modName = myDefinitionId.Context?.ModName;
                }
                if (!MyDefinitionManager.Static.TryGetCubeBlockDefinition(myDefinitionId.Id, out var x))continue;
                sb.AppendLine($"{x.BlockPairName} [{modName} - {modId}]");
            }
            if (Context.Player == null || Context.Player.IdentityId == 0)
            {
                Context.Respond(sb.ToString());
                return;
            }

            ModCommunication.SendMessageTo(new DialogMessage(BlockLimiterConfig.Instance.ServerName,"List of Limits",sb.ToString()),Context.Player.SteamUserId);
        }

        /*
        [Command("change", "gets the list of disabled players per limit")]
        public void ChangeLimit()
        {
            if (!Context.Args.Any())
            {
                Context.Respond("You need to give a limit to change");
                return;
            }
            
            var limit = BlockLimiterConfig.Instance.LimitItems
                .Where(l => l.Name.Equals(Context.Args[0], StringComparison.OrdinalIgnoreCase)).ToList()
                .FirstOrDefault();
            if (limit == null)
            {
                Context.Respond($"No limit with the name {Context.Args[0]} found");
                return;
            }

            var blocks = limit.BlockPairName;

            foreach (var arg in Context.Args)
            {
                if (arg.StartsWith("--name="))
                {
                    limit.Name = arg.Substring("newname=".Length);
                }

                if (arg.StartsWith("--addblocks="))
                {
                    var ns = arg.Substring("--addblocks=".Length);
                    var blockList = ns.Split('"', ',');

                    blockList.ForEach(bl=>blocks.Add(bl));
                    Context.Respond("Blocks added to limit");
                }

                if (arg.StartsWith("--removeblocks="))
                {
                    var ns = arg.Substring("--removeblocks=".Length);
                    var blockList = ns.Split('"', ',');
                    blockList.ForEach(bl=>blocks.Remove(bl));
                    Context.Respond("Blocks removed from limit");
                }
                if (arg.StartsWith("--limit="))
                {
                    limit.Limit = int.Parse(arg.Substring("--limit=".Length));
                    continue;
                }
                if (arg.StartsWith("--projector="))
                {
                    limit.RestrictProjection = bool.Parse(arg.Substring("--projector=".Length));
                    continue;
                }
                if (arg.StartsWith("--player="))
                {
                    limit.LimitPlayers = bool.Parse(arg.Substring("--player=".Length));
                    continue;
                }
                if (arg.StartsWith("--grid="))
                {
                    limit.LimitGrids = bool.Parse(arg.Substring("--grid=".Length));
                    continue;
                }
                if (arg.StartsWith("--faction="))
                {
                    limit.LimitFaction = bool.Parse(arg.Substring("--faction=".Length));
                    continue;
                }
            }
        }*/

    }
}