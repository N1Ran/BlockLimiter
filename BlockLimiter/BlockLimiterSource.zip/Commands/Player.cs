﻿using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using BlockLimiter.Limits;
using BlockLimiter.Settings;
using BlockLimiter.Utility;
using Sandbox.Definitions;
using Sandbox.Game.Entities;
using Sandbox.Game.World;
using Torch;
using Torch.Commands;
using Torch.Commands.Permissions;
using Torch.Mod;
using Torch.Mod.Messages;
using VRage.Dedicated.RemoteAPI;
using VRage.Game.Entity;
using VRage.Game.ModAPI;

namespace BlockLimiter.Commands
{
    [Category("blocklimit")]
    public partial class Player:CommandModule
    {
        [Command("mylimit", "list current player status")]
        [Permission(MyPromoteLevel.None)]
        public void MyLimit()
        {
            if (Context.Player == null || Context.Player.IdentityId == 0)
            {
                Context.Respond("Command can only be run in-game by players");
                return;
            }

            var playerId = Context.Player.IdentityId;

            var newList = new List<LimitItem>();
            var limiterLimits = BlockLimiterConfig.Instance.LimitItems.ToList();
            if (BlockLimiterConfig.Instance.UseVanillaLimits && BlockLimiter.Instance.VanillaLimits?.Any()==false)
            {
                var vanillaLimits = BlockLimiter.Instance.VanillaLimits.Where(x => x.BlockPairName.Any())
                    .ToList();
                newList.AddRange(vanillaLimits);
            }
            
            newList.AddRange(limiterLimits);

            if (!newList.Any())
            {
                Context.Respond("No limit item found");
                return;
            }
            
            var sb = new StringBuilder();

            var grids = MyEntities.GetEntities().OfType<MyCubeGrid>().ToList();
            var playerBlocks = grids
                .SelectMany(x => x.GetBlocks().Where(y => y.BuiltBy == playerId || y.OwnerId == playerId)).ToList();

            if (!playerBlocks.Any())
            {
                Context.Respond("You have no blocks buddy.");
                return;
            }

            var playerFaction = MySession.Static.Factions.GetPlayerFaction(playerId);

            foreach (var item in newList)
            {
                if (!item.BlockPairName.Any()) continue;
                var itemName = string.IsNullOrEmpty(item.Name)?item.BlockPairName.FirstOrDefault():item.Name;
                sb.AppendLine(itemName);
                var count = 0;
                if (item.LimitPlayers)
                {
                    sb.AppendLine("Player Limits");
                    foreach (var block in playerBlocks)
                    {
                        if (!Utilities.IsMatch(block.BlockDefinition,item)) continue;
                        count++;
                    }
                    sb.AppendLine($"BlockLimits = {count}/{item.Limit}");
                }

                if (item.LimitGrids)
                {
                    sb.AppendLine("Grid Limits");
                    foreach (var grid in grids.Where(x=>x.BigOwners.Contains(playerId)))
                    {
                        count = 0;
                        var gridBlocks = grid.GetBlocks();
                        foreach (var block in gridBlocks)
                        {
                            if (!Utilities.IsMatch(block.BlockDefinition,item)) continue;
                            count++;
                        }
                        sb.AppendLine($"{grid.DisplayName} = {count}/{item.Limit}");
                    }
                }
                
                if (playerFaction == null || !item.LimitFaction) continue;
                sb.AppendLine($"Faction Limits: {playerFaction.Tag}");
                count = 0;
                foreach (var block in grids.SelectMany(g=>g.GetFatBlocks().Where(f=>f.GetOwnerFactionTag()==playerFaction.Tag).ToList()))
                {
                    if (!Utilities.IsMatch(block.BlockDefinition, item)) continue;
                    count++;
                    sb.AppendLine($"{playerFaction.Tag} = {count}/{item.Limit}");
                }

            }

            ModCommunication.SendMessageTo(new DialogMessage(BlockLimiterConfig.Instance.ServerName,"PlayerLimit",sb.ToString()),Context.Player.SteamUserId);

        }

        [Command("limits", "gets list of limits and there settings")]
        [Permission(MyPromoteLevel.None)]
        public void GetLimits()
        {
            var sb = new StringBuilder();
            var newList = new List<LimitItem>();
            var limiterLimits = BlockLimiterConfig.Instance.LimitItems.ToList();
            if (BlockLimiterConfig.Instance.UseVanillaLimits && BlockLimiter.Instance.VanillaLimits?.Any()==false)
            {
                var vanillaLimits = BlockLimiter.Instance.VanillaLimits.Where(x => x.BlockPairName.Any())
                    .ToList();
                newList.AddRange(vanillaLimits);
            }
            
            newList.AddRange(limiterLimits);

            if (!newList.Any())
            {
                Context.Respond("No limit item found");
                return;
            }

            sb.AppendLine($"Found {newList.Where(x=>x.BlockPairName.Any()).ToList().Count()} items");
            foreach (var item in newList.Where(x=>x.BlockPairName.Any()))
            {
                var name = string.IsNullOrEmpty(item.Name) ? "No Name" : item.Name;
                sb.AppendLine();
                sb.AppendLine(name);
                item.BlockPairName.ForEach(x=>sb.Append($"[{x}] "));
                sb.AppendLine();
                sb.AppendLine($"Limits:       {item.Limit}");
                sb.AppendLine($"PlayerLimit:  {item.LimitPlayers}");
                sb.AppendLine($"FactionLimit: {item.LimitFaction}");
                sb.AppendLine($"GridLimit:    {item.LimitGrids}");
            }

            if (Context.Player == null || Context.Player.IdentityId == 0)
            {
                Context.Respond(sb.ToString());
                return;
            }

            ModCommunication.SendMessageTo(new DialogMessage(BlockLimiterConfig.Instance.ServerName,"List of Limits",sb.ToString()),Context.Player.SteamUserId);
        }

    }
}