﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using BlockLimiter.Settings;
using BlockLimiter.Utility;
using NLog;
using Sandbox.Definitions;
using Sandbox.Game.Entities;
using Sandbox.Game.Entities.Cube;
using Sandbox.Game.World;
using Torch.Mod;
using Torch.Mod.Messages;
using VRage.Game;
using VRage.Game.Entity;
using VRageRender;

namespace BlockLimiter.Limits
{
    public class Player : LimitsBase
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();

        private HashSet<MyEntity> _entityCache = new HashSet<MyEntity>();


        public override int GetUpdateResolution()
        {
            return 200;
        }

        public override void Handle()
        {

            _entityCache.Clear();
            EntityCache.GetEntities(_entityCache);

            var grids = _entityCache.OfType<MyCubeGrid>().ToList();
            
            if (!grids.Any())
            {
                Log.Debug("No grids found");
                return;
            }

            var limitItems = new List<LimitItem>();

            if (BlockLimiterConfig.Instance.UseVanillaLimits && BlockLimiter.Instance.VanillaLimits.Any())
            {
                var vanillaLimits =
                    BlockLimiter.Instance.VanillaLimits.Where(x => x.LimitPlayers && x.BlockPairName.Any());
                limitItems.AddRange(vanillaLimits);
            }

            limitItems.AddRange(BlockLimiterConfig.Instance.LimitItems.Where(x => x.LimitPlayers));

            if (!limitItems.Any())
            {
                Log.Debug("No player limit found");
                return;
            }

            var blocks = grids.SelectMany(grid => grid.GetFatBlocks().ToList()).ToList();

            if (!blocks.Any())
            {
                Log.Debug("No blocks in existance");
                return;
            }

            var players = MySession.Static.Players.GetOnlinePlayers().ToList();
            
            if (!players.Any())return;

            foreach (var player in players)
            {
                var playerId= player.Identity.IdentityId;
                if (playerId ==0)continue;
                var playerBlocks =blocks.Where(block =>
                    block.BuiltBy == playerId || block.OwnerId == playerId).ToList();

                if (!playerBlocks.Any())continue;
                
                foreach (var item in limitItems)
                {
                    var filteredBlocks = playerBlocks.Where(x => Utilities.IsMatch(x.BlockDefinition, item)).ToList();
                    if (!filteredBlocks.Any() || filteredBlocks.Count < item.Limit)
                    {
                        item.DisabledEntities.Remove(playerId);
                        item.ViolatingEntities.Remove(playerId);
                        continue;
                    }

                    if (!item.DisabledEntities.Contains(playerId)) item.DisabledEntities.Add(playerId);

                    if (filteredBlocks.Count <= item.Limit)
                    {
                        item.ViolatingEntities.Remove(playerId);
                        continue;
                    }
                    if (!item.ViolatingEntities.TryGetValue(playerId, out var limitCount))
                    {
                        item.ViolatingEntities.Add(playerId,filteredBlocks.Count-item.Limit);
                    }

                    item.ViolatingEntities[playerId]=filteredBlocks.Count-item.Limit;

                }
            }
            
            _entityCache.Clear();
        }
    }
}