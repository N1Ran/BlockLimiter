﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Media.Effects;
using BlockLimiter.Settings;
using BlockLimiter.Utility;
using EmptyKeys.UserInterface.Generated.ContractsBlockView_Bindings;
using NLog;
using Sandbox.Definitions;
using Sandbox.Game.Entities;
using Sandbox.Game.World;
using Torch.Mod;
using Torch.Mod.Messages;
using VRage.Game;
using VRage.Game.Entity;


namespace BlockLimiter.Limits
{
    public class Faction : LimitsBase
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();
        private HashSet<MyEntity> _entityCache = new HashSet<MyEntity>();
        private DateTime _nextAnnoyRun;



        public override int GetUpdateResolution()
        {
            return 300;
        }


        public override void Handle()
        {

            _entityCache.Clear();
            EntityCache.GetEntities(_entityCache);
            
            if (_entityCache?.Any() == false)
            {
                Log.Debug("Failed to get entity list in faction limits update");
                return;
            }
            
            var grids = _entityCache.OfType<MyCubeGrid>().ToList();
            
            if (!grids.Any())
            {
                Log.Debug("No grids found");
                return;
            }

            var limitItems = new List<LimitItem>();
            if (BlockLimiterConfig.Instance.UseVanillaLimits && BlockLimiter.Instance.VanillaLimits.Any())
            {
                var vanillaLimits = BlockLimiter.Instance.VanillaLimits.Where(x => x.LimitFaction && x.BlockPairName.Any());
                limitItems.AddRange(vanillaLimits);
                
            }
            
            limitItems.AddRange(BlockLimiterConfig.Instance.LimitItems.Where(x=>x.LimitFaction));

            if (!limitItems.Any())
            {
                Log.Debug("No Grid limit found");
                return;
            }

            var blocks = grids.SelectMany(grid => grid.GetFatBlocks()).ToList();
            
            if (!blocks.Any())return;

            var allFactions = MySession.Static.Factions.Factions.Where(x=>x.Value?.IsEveryoneNpc() == false).Select(x=>x.Value).ToList();

            foreach (var faction in allFactions)
            {
                if (!faction.Members.Any(x=>MySession.Static.Players.IsPlayerOnline(x.Value.PlayerId)))continue;
                var factionBlocks = blocks.Where(x => x.GetOwnerFactionTag() == faction.Tag).ToList();
                if (!factionBlocks.Any())continue;
                foreach (var item in limitItems)
                {
                    var filteredBlocks = factionBlocks.Where(block =>
                        Utilities.IsMatch(block.BlockDefinition, item)).ToList();
                    if (!filteredBlocks.Any() || filteredBlocks.Count < item.Limit)
                    {
                        item.DisabledEntities.Remove(faction.FactionId);
                        item.ViolatingEntities.Remove(faction.FactionId);
                        continue;

                    }
                    if (!item.DisabledEntities.Contains(faction.FactionId))item.DisabledEntities.Add(faction.FactionId);

                    if (filteredBlocks.Count <= item.Limit)
                    {
                        item.ViolatingEntities.Remove(faction.FactionId);
                        continue;
                    }
                    if (!item.ViolatingEntities.TryGetValue(faction.FactionId, out var limitCount))
                    {
                        item.ViolatingEntities.Add(faction.FactionId,filteredBlocks.Count-item.Limit);
                    }

                    item.ViolatingEntities[faction.FactionId]=filteredBlocks.Count-item.Limit;

                }
            }

            _entityCache.Clear();


        }


        


    }
}